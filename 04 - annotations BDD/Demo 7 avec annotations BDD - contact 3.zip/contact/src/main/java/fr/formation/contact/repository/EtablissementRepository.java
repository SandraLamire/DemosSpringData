package fr.formation.contact.repository;

import org.springframework.data.repository.CrudRepository;

import fr.formation.contact.entity.Etablissement;

public interface EtablissementRepository extends CrudRepository<Etablissement,Integer>{

}
