package fr.formation.contact.repository;

import org.springframework.data.repository.CrudRepository;

import fr.formation.contact.entity.MaisonMere;

public interface MaisonMereRepository extends CrudRepository<MaisonMere, Integer>{

}
