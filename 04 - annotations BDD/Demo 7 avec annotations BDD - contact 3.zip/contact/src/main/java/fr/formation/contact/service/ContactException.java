package fr.formation.contact.service;

public class ContactException extends Exception {

	public ContactException(String message) {
		super(message);
	}

}
