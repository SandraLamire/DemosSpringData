package fr.eni.demo.bo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of= {"immatriculation"})
@ToString
@Data
////Possible d'utiliser l'annotation @Builder pour produire des API de construction complexe
@Builder
/**
 * 
 * @author Eni Ecole
 * Voici une classe BO (Business Object)
 * Respectant le design pattern POJO (Plained Old Java Object)
 * Définie avec Lombok
 */
public class Employe {
	//Attributs
	private Integer id;
	private String nom;
	private String prenom;
	private String email;
	private String immatriculation;
	private String numDom;
	private String numPortable;
}
