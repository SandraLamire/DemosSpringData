package fr.eni.demo.bo.factory;

import fr.eni.demo.bo.Employe;
import lombok.Builder;
import lombok.experimental.UtilityClass;

@UtilityClass
public class EmployeFactory {
	@Builder(builderMethodName = "nveauCandidat")
	public static Employe nveauCandidat(String nom, String prenom) {
		return Employe.builder().nom(nom).prenom(prenom).build();
	}

	@Builder(builderMethodName = "nvelEmploye")
	public static Employe nvelEmploye(String nom, String prenom, String email, String immatriculation) {
		return Employe.builder().nom(nom).prenom(prenom).email(email).immatriculation(immatriculation).build();
	}
}