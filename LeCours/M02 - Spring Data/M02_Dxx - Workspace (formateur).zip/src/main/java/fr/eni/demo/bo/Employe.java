package fr.eni.demo.bo;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = { "immatriculation" })
@ToString
//@Data
//Possible d'utiliser l'annotation @Builder pour produire des API de construction complexe
@SuperBuilder
/**
 * 
 * @author Eni Ecole
 * 
 *         Voici une classe BO (Business Object)
 * 
 *         Respectant le design pattern POJO (Plained Old Java Object)
 * 
 *         Définie avec Lombok
 * 
 *         Elle est maintenant déclarée comme une entité JPA
 */
@Entity
@Table(name = "EMPLOYEE")
@Inheritance(strategy = InheritanceType.JOINED)
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
//@DiscriminatorColumn(name = "DISCR")
//@DiscriminatorValue(value = "E")
public class Employe {
	// Attributs
	// Clef primaire -- gestion par IDENTITY
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// Clef primaire -- gestion par TABLE
	//@GeneratedValue(strategy = GenerationType.TABLE)
	@Id
	@Column(name = "EMPLOYEE_ID")
	private Integer id;

	// Ajout de l'association ManyToOne
	@ManyToOne
	@JoinColumn(name = "CIVILITY_ID")
	private Civilite civilite;

	// Précision sur le nom de la colonne : name=
	// Cette colonne est non nulle -> nullable = false
	// La taille de la colonne en base est de 90 -> length = 90
	@Column(name = "LAST_NAME", nullable = false, length = 90)
	private String nom;

	@Column(name = "FIRST_NAME", nullable = false, length = 150)
	private String prenom;

	// La valeur de l'email est unique -> unique = true
	@Column(nullable = false, unique = true, length = 255)
	private String email;

	@Column(name = "EMPLOYEE_REGISTRATION", nullable = false, unique = true, length = 100)
	private String immatriculation;

	@Column(name = "HOME_PHONE_NUMBER", length = 12)
	private String numDom;

	@Column(name = "CELL_NUMBER", length = 12)
	private String numPortable;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "ADDRESS_ID")
	private Adresse adresse;
}
