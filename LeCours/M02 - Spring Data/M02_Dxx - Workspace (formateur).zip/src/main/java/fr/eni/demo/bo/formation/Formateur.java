package fr.eni.demo.bo.formation;

import java.util.ArrayList;
import java.util.List;

import fr.eni.demo.bo.Employe;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@SuperBuilder
/**
 * 
 * @author Eni Ecole
 */
@Entity
@Table(name = "TRAINER")
//@DiscriminatorValue(value = "F")
public class Formateur extends Employe {

	@Column(name = "COMPUTER_SCIENCE_COURSE", length = 150)
	@ToString.Include
	private String filiere;

	// Association ManyToMany
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "COMPUTER_COURSES_PROVIDED", joinColumns = {
			@JoinColumn(name = "TRAINER_ID") }, 
			inverseJoinColumns = { @JoinColumn(name = "COMPUTER_COURSE_ID") })
	@ToString.Exclude
	@Builder.Default
	private List<Cours> coursDispenses = new ArrayList<>();
}
