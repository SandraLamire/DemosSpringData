package fr.eni.demo.bo.stagiaire;

import jakarta.persistence.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * 
 * @author Eni Ecole
 * 
 * @category Voici une entité avec une clef composite correspondant à l'email et
 *           l'immatriculation
 */
@Entity
@Table(name = "ENI_STUDENT")

public class EtudiantEni {
	@Id
	@Column(name = "STUDENT_REGISTRATION", nullable = false, unique = true, length = 100)
	private String immatriculation;

	@Column(nullable = false, unique = true, length = 255)
	private String email;

	// Association bidirectionnelle
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "DATA_ID")
	private DonneesPerso donneesPerso;

	// Association Bidirectionnelle avec Promo
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "CLASS_ID")
	@ToString.Exclude
	private Promo promo;

}
