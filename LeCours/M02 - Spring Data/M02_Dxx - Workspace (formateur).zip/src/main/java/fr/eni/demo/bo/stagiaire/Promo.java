package fr.eni.demo.bo.stagiaire;

import java.util.*;

import jakarta.persistence.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

@Entity
@Table(name = "STUDENT_CLASS")
public class Promo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "NAME", nullable = false, length = 12)
	private String nom;
	
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy = "promo", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
	//@JoinColumn(name="STUDENT_ID")
	private @Builder.Default List<EtudiantEni> etudiants = new ArrayList<>();
}
