package fr.eni.demo.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.Adresse;

public interface AdresseRepository extends JpaRepository<Adresse, Integer>{

}
