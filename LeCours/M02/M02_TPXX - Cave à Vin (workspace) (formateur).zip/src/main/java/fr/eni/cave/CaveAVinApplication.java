package fr.eni.cave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaveAVinApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaveAVinApplication.class, args);
	}

}
