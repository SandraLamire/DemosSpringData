package fr.eni.demo.bo.clefcomposite;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.*;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Document(collection = "computer_course")
public class Cours {

	@Id
	private CoursId id;

	@Field(name = "title")
	private String titre;

	@Field(name = "duration")
	private int duree;
}
