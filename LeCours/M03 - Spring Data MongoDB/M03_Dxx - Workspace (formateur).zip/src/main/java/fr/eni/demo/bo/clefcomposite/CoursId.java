package fr.eni.demo.bo.clefcomposite;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Builder
public class CoursId implements Serializable{
	private static final long serialVersionUID = 1L;

	private String reference;

	@Field(name = "computer_science_course")
	private String filiere;
}
