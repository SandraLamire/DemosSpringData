package fr.eni.demo.dal;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

import fr.eni.demo.bo.*;
import fr.eni.demo.bo.clefcomposite.Cours;

public interface AvisRepository extends MongoRepository<Avis, String> {
	List<Avis> findByNoteCours(@Param("noteCours") int noteCours);

	List<Avis> findByNoteCoursGreaterThan(@Param("noteCours") int noteCours);

	List<Avis> findByNoteCoursLessThan(@Param("noteCours") int noteCours);

	List<Avis> findByStagiaire(@Param("stagiaire") Stagiaire stagiaire);
	
	List<Avis> findByFormateur(@Param("f") Formateur f);
	
	List<Avis> findByCours(@Param("c") Cours c);
}
