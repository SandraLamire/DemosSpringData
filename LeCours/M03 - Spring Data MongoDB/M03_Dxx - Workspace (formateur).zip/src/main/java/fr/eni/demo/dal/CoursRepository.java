package fr.eni.demo.dal;

import org.springframework.data.mongodb.repository.MongoRepository;

import fr.eni.demo.bo.clefcomposite.Cours;
import fr.eni.demo.bo.clefcomposite.CoursId;

public interface CoursRepository extends MongoRepository<Cours, CoursId> {

}
