package fr.eni.gestionavis.bo.vin;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.*;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Document(collection = "bottles")
public class Bouteille {

	@Id
	private BouteilleId id;

	@Field(name = "name")
	private String nom;
		
}
