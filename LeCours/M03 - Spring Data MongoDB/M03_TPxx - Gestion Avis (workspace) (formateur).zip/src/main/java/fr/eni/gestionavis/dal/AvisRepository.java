package fr.eni.gestionavis.dal;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;

import fr.eni.gestionavis.bo.Avis;
import fr.eni.gestionavis.bo.vin.Bouteille;

public interface AvisRepository extends MongoRepository<Avis, String> {
	// Les Avis qui ont une note < à la note en paramètre
	List<Avis> findByNoteLessThan(@Param("note") int note);

	// Les Avis qui ont une note ≥ à la note en paramètre
	List<Avis> findByNoteGreaterThan(@Param("note") int note);

	// Remonter les Avis associé à une Bouteille
	List<Avis> findByBouteille(@Param("bouteille") Bouteille bouteille);

	// Remonter les Avis selon le pseudo d’un Client
	List<Avis> findByClientPseudo(@Param("pseudo") String pseudo);

	// Remonter les Avis dont la quantité commandée dépasse celle en paramètre
	List<Avis> findByClientQuantiteCommandeeGreaterThan(@Param("qte") int qte);

	// Remonter les Avis dont la date est entre les 2 dates en paramètres
	List<Avis> findByDateBetween(@Param("deb") LocalDateTime deb,@Param("fin")  LocalDateTime fin);
}
