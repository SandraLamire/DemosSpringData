package fr.eni.gestionavis.dal;

import org.springframework.data.mongodb.repository.MongoRepository;

import fr.eni.gestionavis.bo.vin.*;

public interface BouteilleRepository extends MongoRepository<Bouteille, BouteilleId>{

}
