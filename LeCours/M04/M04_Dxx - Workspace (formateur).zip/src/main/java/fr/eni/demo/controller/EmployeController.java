package fr.eni.demo.controller;

import java.util.*;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import fr.eni.demo.bll.EmployeService;
import fr.eni.demo.bo.Employe;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@AllArgsConstructor

@RestController
@RequestMapping("/eniecole/employes")
public class EmployeController {
	private EmployeService employeService;

	@GetMapping
	public ResponseEntity<?> rechercherTousEmployes() {
		final List<Employe> employes = employeService.chargerTousEmployes();// new ArrayList<>();
		if (employes == null || employes.isEmpty()) {
			// Statut 204 : No Content - Pas de body car rien à afficher
			return ResponseEntity.noContent().build();
		}
		// Statut 200 : OK + dans le body employes
		// Le contenu du body est directement injecté dans la méthode ok
		return ResponseEntity.ok(employes);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> rechercherEmployeParId(@PathVariable("id") String idInPath) {
		// Toutes les données transmises par le protocole HTTP sont des chaines de
		// caractères par défaut
		// Il vaut mieux gérer les exceptions des données dans la méthode
		try {
			int id = Integer.parseInt(idInPath);
			final Employe emp = employeService.chargerUnEmployeParId(id);
			return ResponseEntity.ok(emp);
		} catch (NumberFormatException e) {
			// Statut 406 : No Acceptable
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Votre identifiant n'est pas un entier");
		} catch (RuntimeException e) {
			// Statut 404 : Not Found
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@PostMapping
	public ResponseEntity<?> ajoutEmploye(@Valid @RequestBody Employe employe) {
		try {
			employeService.ajouter(employe);
			return ResponseEntity.ok(employe);
		} catch (RuntimeException e) {
			// Erreur BLL ou DAL
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(e.getMessage());
		}
	}
}
