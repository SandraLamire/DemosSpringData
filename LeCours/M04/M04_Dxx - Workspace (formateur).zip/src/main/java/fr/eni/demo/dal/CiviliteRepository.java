package fr.eni.demo.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.Civilite;

public interface CiviliteRepository extends JpaRepository<Civilite, String> {

}
