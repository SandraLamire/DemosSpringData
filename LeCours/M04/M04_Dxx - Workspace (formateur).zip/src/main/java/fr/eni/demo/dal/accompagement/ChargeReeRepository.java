package fr.eni.demo.dal.accompagement;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.accompagement.ChargeRelationsEcoleEntreprises;

public interface ChargeReeRepository extends JpaRepository<ChargeRelationsEcoleEntreprises, Integer>{

}
