package fr.eni.demo.association;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.*;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.*;

import fr.eni.demo.bo.stagiaire.*;
import fr.eni.demo.dal.PromoRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestOneToManyBi {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	PromoRepository promoRepository;

	@Test
	public void test_save() {
		final Promo promo = Promo
				.builder()
				.nom("EDWM_TEST")
				.build();

		// Association Bidirectionnelle
		List<EtudiantEni> etudiants = jeuDeDonnees();
		promo.setEtudiants(jeuDeDonnees());

		etudiants.forEach(etudiant -> {
			etudiant.setPromo(promo);
		});

		// Appel du comportement
		final Promo promoDB = promoRepository.save(promo);
		// Vérification de l'identifiant
		assertThat(promoDB.getId()).isGreaterThan(0);

		// Vérification de la cascade de l'association
		assertThat(promoDB.getEtudiants()).isNotNull();
		assertThat(promoDB.getEtudiants()).isNotEmpty();
		assertThat(promoDB.getEtudiants().size()).isEqualTo(3);
		log.info(promoDB.toString());
	}

	@Test
	public void test_delete() {
		final Promo promo = Promo
				.builder()
				.nom("EDWM_TEST")
				.build();

		// Association OneToMany Bidirectionnelle
		final List<EtudiantEni> etudiants = jeuDeDonnees();
		promo.setEtudiants(etudiants);
		etudiants.forEach(etudiant -> {
			etudiant.setPromo(promo);
		});

		// Contexte de la DB
		final Promo promoDB = entityManager.persist(promo);
		entityManager.flush();
		assertThat(promoDB.getId()).isGreaterThan(0);
		assertThat(promoDB.getEtudiants()).isNotNull();
		assertThat(promoDB.getEtudiants()).isNotEmpty();
		List<EtudiantEni> etudiantsDB = promoDB.getEtudiants();
		List<String> listeIdEtudiantEniDB = etudiantsDB
				.stream()
				.map(EtudiantEni::getImmatriculation)
				.collect(Collectors.toList());

		// Appel du comportement
		promoRepository.delete(promoDB);

		// Vérification que l'entité a été supprimée
		final Promo promoDB2 = entityManager.find(Promo.class, promo.getId());
		assertNull(promoDB2);
		// Vérifier que tous les employés sont supprimés par cascade
		assertThat(listeIdEtudiantEniDB).isNotNull();
		assertThat(listeIdEtudiantEniDB).isNotEmpty();
		listeIdEtudiantEniDB.forEach(etudiantId -> {
			assertThat(etudiantId).isNotNull();
			EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, etudiantId);
			assertNull(etudiantDB);
		});
	}

	@Test
	public void test_orphanRemoval() {
		final Promo promo = Promo
				.builder()
				.nom("EDWM_TEST")
				.build();

		// Association OneToMany Bidirectionnelle
		final List<EtudiantEni> etudiants = jeuDeDonnees();
		promo.setEtudiants(etudiants);
		etudiants.forEach(etudiant -> {
			etudiant.setPromo(promo);
		});

		// Contexte de la DB
		final Promo promoDB = entityManager.persist(promo);
		entityManager.flush();
		assertThat(promoDB.getId()).isGreaterThan(0);
		assertThat(promoDB.getEtudiants()).isNotNull();
		assertThat(promoDB.getEtudiants()).isNotEmpty();
		List<EtudiantEni> etudiantsDB = promoDB.getEtudiants();
		List<String> listeIdEtudiantEniDB = etudiantsDB
				.stream()
				.map(EtudiantEni::getImmatriculation)
				.collect(Collectors.toList());

		// Détacher les employés de leur promo
		promo.getEtudiants().clear();

		// Appel du comportement
		promoRepository.delete(promo);

		// Vérification que l'entité a été supprimée
		final Promo promoDB2 = entityManager.find(Promo.class, promo.getId());
		assertNull(promoDB2);

		// Vérifier que tous les employés sont supprimés par orphanRemoval
		assertThat(listeIdEtudiantEniDB).isNotNull();
		assertThat(listeIdEtudiantEniDB).isNotEmpty();
		listeIdEtudiantEniDB.forEach(etudiantId -> {
			assertThat(etudiantId).isNotNull();
			EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, etudiantId);
			assertNull(etudiantDB);
		});
	}

	private List<EtudiantEni> jeuDeDonnees() {
		final List<EtudiantEni> etudiants = new ArrayList<>();
		String immatriculation = "ENI_CAMPUS_20231187";

		for (int i = 1; i < 4; i++) {
			final DonneesPerso donneesPerso = DonneesPerso
					.builder()
					.nom("Nom" + i)
					.prenom("Prenom" + i)
					.numDom("02XXXXXXXX")
					.numPortable("07XXXXXXXX")
					.emailPersonnel("Nom" + i + ".Prenom" + i + "@perso.fr")
					.build();
			final EtudiantEni etudiant = EtudiantEni
					.builder()
					.immatriculation(immatriculation + i)
					.email("pnom" + i + "@campus-eni.fr")
					.build();
			etudiant.setDonneesPerso(donneesPerso);
			donneesPerso.setEtudiantEni(etudiant);

			etudiants.add(etudiant);
		}

		return etudiants;
	}
}
