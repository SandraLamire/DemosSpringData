package fr.eni.demo.association;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.Adresse;
import fr.eni.demo.bo.Employe;
import fr.eni.demo.dal.EmployeRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestOneToOneUni {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EmployeRepository repository;

	@Test
	public void test_save() {
		final Adresse adresse = Adresse
				.builder()
				.rue("15 rue de Paris")
				.codePostal("35000")
				.ville("Rennes")
				.build();

		final Employe employe = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Association
		employe.setAdresse(adresse);

		// Appel du comportement
		final Employe employeDB = repository.save(employe);
		log.info(employeDB.toString());

		// Vérification de l'identifiant de l'employé
		assertThat(employeDB.getId()).isGreaterThan(0);

		// Vérification de la cascade de l'association
		assertThat(adresse.getId()).isGreaterThan(0);
	}

	@Test
	public void test_delete() {
		final Adresse adresse = Adresse
				.builder()
				.rue("15 rue de Paris")
				.codePostal("35000")
				.ville("Rennes")
				.build();

		final Employe employe = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Association
		employe.setAdresse(adresse);

		// Contexte de la DB
		entityManager.persist(employe);
		entityManager.flush();
		assertThat(employe.getId()).isGreaterThan(0);
		assertThat(adresse.getId()).isGreaterThan(0);

		// Appel du comportement
		repository.delete(employe);

		// Vérification que l'entité a été supprimée
		Employe employeDB = entityManager.find(Employe.class, employe.getId());
		assertNull(employeDB);
		Adresse adresseDB = entityManager.find(Adresse.class, adresse.getId());
		assertNull(adresseDB);
	}
	
	
	@Test
	public void test_orphanRemoval() {
		final Adresse adresse = Adresse
				.builder()
				.rue("15 rue de Paris")
				.codePostal("35000")
				.ville("Rennes")
				.build();

		final Employe employe = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Association
		employe.setAdresse(adresse);

		// Contexte de la DB
		entityManager.persist(employe);
		entityManager.flush();
		assertThat(employe.getId()).isGreaterThan(0);
		assertThat(adresse.getId()).isGreaterThan(0);
		
		//Supprimer le lien entre l'entité Employe et l'entité Adresse
		employe.setAdresse(null);

		// Appel du comportement
		repository.delete(employe);

		// Vérification que l'entité a été supprimée
		Employe employeDB = entityManager.find(Employe.class, employe.getId());
		assertNull(employeDB);
		
		Adresse adresseDB = entityManager.find(Adresse.class, adresse.getId());
		assertNull(adresseDB);
	}
}
