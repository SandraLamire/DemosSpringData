package fr.eni.demo.bll;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import fr.eni.demo.bo.Employe;
import fr.eni.demo.dal.AdresseRepository;
import fr.eni.demo.dal.EmployeRepository;

class TestEmployeService {
	private EmployeService employeService;

	@Mock // Injection d'un Mock du EmployeRepository
	private EmployeRepository employeRepository;
	
	@Mock // Injection d'un Mock du AdresseRepository
	private AdresseRepository adresseRepository;

	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
		employeService = new EmployeServiceImpl(employeRepository, adresseRepository);
	}

	@Test
	void test01_ajouter_tousParametresValides() {
		int id = 1;
		Employe employe = Employe
				.builder()
				.id(id)
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_Ecole_012892")
				.numDom("0299XXXXXX")
				.numPortable("0699XXXXXX")
				.build();

		// Définir le comportement du Repository mocké
		 when(employeRepository.findById(id)).thenReturn(Optional.of(employe));
		 
		// Comportemnet à valider
		employeService.ajouter(employe);

		// Vérification de l'ajout dans la liste des employés
	    Optional<Employe> op = employeRepository.findById(id);
	    assertNotNull(op);
	    assertThat(op.isPresent()).isTrue();
	    final Employe employeDB = op.get();
		assertNotNull(employeDB);
		assertThat(employe.getImmatriculation()).isEqualTo(employeDB.getImmatriculation());
		assertThat(employe.getEmail()).isEqualTo(employeDB.getEmail());
		assertThat(employe.getNom()).isEqualTo(employeDB.getNom());
		assertThat(employe.getPrenom()).isEqualTo(employeDB.getPrenom());
		assertThat(employe.getNumDom()).isEqualTo(employeDB.getNumDom());
		assertThat(employe.getNumPortable()).isEqualTo(employeDB.getNumPortable());
	}

	// Employe null
	@Test
	void test_ajouter_employe_null() {
		assertThrows(RuntimeException.class, () -> employeService.ajouter(null));
	}

	// Nom nul - la validation métier l'interdit - nom est obligatoire
	@Test
	void test_ajouter_sansNom() {
		Employe employe = Employe
				.builder()
				.id(2)
				.prenom("Stephane")
				.email("sgobin@campus-eni.fr")
				.immatriculation("ENI_Ecole_012111")
				.numDom("0288XXXXXX")
				.build();
		assertThrows(RuntimeException.class, () -> employeService.ajouter(employe));
	}

	// Immatriculation vide ou nulle - la validation métier l'interdit
	@Test
	void test_ajouter_immatriculationVide() {
		Employe employe = Employe
				.builder()
				.id(2)
				.nom("GOBIN")
				.prenom("Stephane")
				.email("sgobin@campus-eni.fr")
				.immatriculation("")
				.numDom("0288XXXXXX")
				.build();
		assertThrows(RuntimeException.class, () -> employeService.ajouter(employe));
	}

	// Immatriculation Unique - la validation métier l'interdit
	@Test
	void test_ajouter_immatriculationUnique() {
		Employe employe1 = Employe
				.builder()
				.id(1)
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_Ecole_012892")
				.numDom("0299XXXXXX")
				.numPortable("0699XXXXXX")
				.build();
		employeService.ajouter(employe1);

		// Définir le comportement du Repository avec findByImmatriculation
		//Méthode de requête :  findByImmatriculation
		when(employeRepository.findByImmatriculation("ENI_Ecole_012892")).thenReturn(employe1);

		Employe employe2 = Employe
				.builder()
				.id(2)
				.nom("GOBIN")
				.prenom("Stephane")
				.email("sgobin@campus-eni.fr")
				.immatriculation("ENI_Ecole_012892")
				.numDom("0288XXXXXX")
				.build();
		assertThrows(RuntimeException.class, () -> employeService.ajouter(employe2));
	}
	
	@Test
	void test_chargerTousEmployes_isEmpty() {
		final List<Employe> lstEmployes = employeService.chargerTousEmployes();
		assertThat(lstEmployes).isEmpty();
	}

	@Test
	void test_chargerTousEmployes() {
		// Arrange
		List<Employe> employes = new ArrayList<>();
		employes.add(
				Employe
						.builder()
						.id(1)
						.nom("BAILLE")
						.prenom("Anne-Lise")
						.email("abaille@campus-eni.fr")
						.immatriculation("ENI_Ecole_012892")
						.numDom("0299XXXXXX")
						.numPortable("0699XXXXXX")
						.build());
		employes.add(
				Employe
						.builder()
						.id(2)
						.nom("GOBIN")
						.prenom("Stephane")
						.email("sgobin@campus-eni.fr")
						.immatriculation("ENI_Ecole_012111")
						.numDom("0288XXXXXX")
						.build());
		when(employeRepository.findAll()).thenReturn(employes);

		// Act
		List<Employe> result = employeService.chargerTousEmployes();

		// Assert
		assertEquals(2, result.size());
		assertEquals("ENI_Ecole_012892", result.get(0).getImmatriculation());
		assertEquals("ENI_Ecole_012111", result.get(1).getImmatriculation());
	}

}
