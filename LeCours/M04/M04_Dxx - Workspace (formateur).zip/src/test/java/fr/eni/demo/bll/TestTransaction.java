package fr.eni.demo.bll;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import fr.eni.demo.bo.Adresse;
import fr.eni.demo.bo.Employe;
import fr.eni.demo.dal.AdresseRepository;
import fr.eni.demo.dal.EmployeRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class TestTransaction {
	@Autowired
	private EmployeService employeService;

	@Autowired
	private EmployeRepository employeRepository;

	@Autowired
	private AdresseRepository adresseRepository;

	@Test
	public void test_transaction_Ok() {
		final Adresse adresse = Adresse
				.builder()
				.rue("100 rue de Rennes")
				.codePostal("44000")
				.ville("Nantes")
				.build();

		final Employe employe = Employe
				.builder()
				.nom("GOBIN")
				.prenom("Stéphane")
				.email("sgobin@campus-eni.fr")
				.immatriculation("ENI_Ecole_011112")
				.numDom("0288XXXXXX")
				.build();

		// Appel du comportement
		employeService.ajouterEmploye(employe, adresse);

		// L'employé a été enregistré
		assertThat(employe.getId()).isGreaterThan(0);
		log.info(employe.toString());
		
		// L'adresse a été enregistré
		assertThat(adresse.getId()).isGreaterThan(0);
		log.info(adresse.toString());
	}

	@Test
	public void test_transaction_Rollback() {
		final Adresse adresse = Adresse
				.builder()
				.rue("15 rue de Paris")
				.ville("Rennes")
				.build();

		final Employe employe = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Appel du comportement
		assertThrows(RuntimeException.class, () -> employeService.ajouterEmploye(employe, adresse));

		// Vérifions les données en base
		List<Adresse> adresses = adresseRepository.findAll();
		assertThat(adresses).isNotNull();
		Adresse adresseDB = adresses
				.stream()
				.filter(item -> item.getVille().equals("Rennes"))
				.findAny()
				.orElse(null);
		assertThat(adresseDB).isNull();

		List<Employe> employes = employeRepository.findAll();
		Employe employeDB = employes
				.stream()
				.filter(item -> item.getImmatriculation()
						.equals("ENI_ECOLE_12398"))
				.findAny()
				.orElse(null);
		assertThat(employeDB).isNull();
	}

}
