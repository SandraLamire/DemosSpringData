package fr.eni.demo.dal;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.pk2.Etudiant2;
import fr.eni.demo.bo.pk2.EtudiantPK2;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestEtudiant2Repository {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	Etudiant2Repository repository;

	@Test
	public void test_save() {
		final EtudiantPK2 pk = EtudiantPK2
				.builder()
				.email("csoprano@campus-eni.fr")
				.immatriculation("ENI_CAMPUS_202311872")
				.build();
		
		final Etudiant2 entiteASauver = Etudiant2
				.builder()
				.pk(pk)
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		// Appel du comportement
		final Etudiant2 entite = repository.save(entiteASauver);
		assertThat(entite).isNotNull();
		log.info(entite.toString());

		final Etudiant2 entiteDB = entityManager.find(Etudiant2.class, pk);
		assertThat(entiteDB).isNotNull();
		assertThat(entite).isEqualTo(entiteDB);
	}

}
