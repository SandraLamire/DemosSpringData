package fr.eni.cave.controller;

import java.util.List;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import fr.eni.cave.bll.BouteilleService;
import fr.eni.cave.bo.vin.Bouteille;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/caveavin/bouteilles")
public class BouteilleController {
	private BouteilleService bService;

	// Pour visiteur, Client et Proprio

	@GetMapping
	public ResponseEntity<?> rechercherTousBouteilles() {
		final List<Bouteille> bouteilles = bService.chargerToutesBouteilles();
		if (bouteilles == null || bouteilles.isEmpty()) {
			// Statut 204 : No Content - Pas de body car rien à afficher
			return ResponseEntity.noContent().build();
		}
		// Statut 200 : OK + dans le body bouteilles
		// Le contenu du body est directement injecté dans la méthode ok
		return ResponseEntity.ok(bouteilles);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> rechercherBouteilleParId(@PathVariable("id") String idInPath) {
		// Toutes les données transmises par le protocole HTTP sont des chaines de
		// caractères par défaut
		// Il vaut mieux gérer les exceptions des données dans la méthode
		try {
			int id = Integer.parseInt(idInPath);
			final Bouteille emp = bService.chargerBouteilleParId(id);
			return ResponseEntity.ok(emp);
		} catch (NumberFormatException e) {
			// Statut 406 : No Acceptable
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Votre identifiant n'est pas un entier");
		}
	}

	@GetMapping("/region/{id}")
	public ResponseEntity<?> rechercherBouteillesParRegion(@PathVariable("id") String idInPath) {
		try {
			final int idRegion = Integer.parseInt(idInPath);

			final List<Bouteille> bouteilles = bService.chargerBouteillesParRegion(idRegion);
			return ResponseEntity.ok(bouteilles);
		} catch (NumberFormatException e) {
			// Statut 406 : No Acceptable
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Votre identifiant n'est pas un entier");
		}
	}

	@GetMapping("/couleur/{id}")
	public ResponseEntity<?> rechercherBouteillesParCouleur(@PathVariable("id") String idInPath) {
		try {
			final int idCouleur = Integer.parseInt(idInPath);

			final List<Bouteille> bouteilles = bService.chargerBouteillesParCouleur(idCouleur);
			return ResponseEntity.ok(bouteilles);
		} catch (NumberFormatException e) {
			// Statut 406 : No Acceptable
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Votre identifiant n'est pas un entier");
		}
	}

	// Pour le Proprio
	@PostMapping
	public ResponseEntity<?> ajouterBouteille(@Valid @RequestBody Bouteille bouteille) {
		try {
			bService.ajouter(bouteille);
			return ResponseEntity.ok(bouteille);
		} catch (RuntimeException e) {
			// Erreur BLL ou DAL
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(e.getMessage());
		}
	}

	// Pour le Proprio
	@PutMapping
	public ResponseEntity<?> miseAJourBouteille(@Valid @RequestBody Bouteille bouteille) {
		try {
			if (bouteille == null || bouteille.getId() == null || bouteille.getId() <= 0) {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE)
						.body("La bouteille et l'identifiant sont obligatoires");
			}
			bService.ajouter(bouteille);
			return ResponseEntity.ok(bouteille);
		} catch (RuntimeException e) {
			// Erreur BLL ou DAL
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(e.getMessage());
		}
	}

	// Pour le Proprio
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteBouteille(@PathVariable("id") String idInPath) {
		try {
			final int idBouteille = Integer.parseInt(idInPath);
			bService.supprimer(idBouteille);
			return ResponseEntity.ok("Bouteille (" + idBouteille + ") est supprimée");
		} catch (NumberFormatException e) {
			// Statut 406 : No Acceptable
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body("Votre identifiant n'est pas un entier");
		} catch (RuntimeException e) {
			// Erreur BLL ou DAL
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(e.getMessage());
		}
	}
}
