package fr.eni.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoNosqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoNosqlApplication.class, args);
	}

}
