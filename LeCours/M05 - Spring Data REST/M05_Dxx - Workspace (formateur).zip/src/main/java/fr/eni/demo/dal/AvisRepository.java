package fr.eni.demo.dal;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import fr.eni.demo.bo.Avis;

@RepositoryRestResource(collectionResourceRel = "avis", path = "avis")
public interface AvisRepository extends MongoRepository<Avis, String> {
	List<Avis> findByNoteCours(@Param("noteCours") int noteCours);

	List<Avis> findByNoteCoursGreaterThan(@Param("noteCours") int noteCours);

	List<Avis> findByNoteCoursLessThan(@Param("noteCours") int noteCours);

	// List<Avis> findByStagiaire(@Param("stagiaire") Stagiaire stagiaire);
	List<Avis> findByStagiaireImmatriculation(@Param("immatriculation") String immatriculation);

	// List<Avis> findByFormateur(@Param("f") Formateur f);
	List<Avis> findByFormateurEmail(@Param("email") String email);

	// List<Avis> findByCours(@Param("c") Cours c);
	List<Avis> findByCoursReference(@Param("reference") String reference);

}
