package fr.eni.gestionavis.dal;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.format.annotation.DateTimeFormat;

import fr.eni.gestionavis.bo.Avis;
//import fr.eni.gestionavis.bo.vin.Bouteille;

@RepositoryRestResource(collectionResourceRel = "avis", path = "avis")
public interface AvisRepository extends MongoRepository<Avis, String> {
	// Les Avis qui ont une note < à la note en paramètre
	List<Avis> findByNoteLessThan(@Param("note") int note);

	// Les Avis qui ont une note ≥ à la note en paramètre
	List<Avis> findByNoteGreaterThan(@Param("note") int note);

	// Remonter les Avis associé à une Bouteille
	//List<Avis> findByBouteille(@Param("bouteille") Bouteille bouteille);
	List<Avis> findByBouteilleIdBouteille(@Param("idBouteille") Integer idBouteille);

	// Remonter les Avis selon le pseudo d’un Client
	List<Avis> findByClientPseudo(@Param("pseudo") String pseudo);

	// Remonter les Avis dont la quantité commandée dépasse celle en paramètre
	List<Avis> findByClientQuantiteCommandeeGreaterThan(@Param("qte") int qte);

	// Remonter les Avis dont la date est entre les 2 dates en paramètres
	// ++ pour gérer une date au travers de Spring Data REST utiliser @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
	List<Avis> findByDateBetween(@Param("deb") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime deb, @Param("fin")@DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fin);
}
