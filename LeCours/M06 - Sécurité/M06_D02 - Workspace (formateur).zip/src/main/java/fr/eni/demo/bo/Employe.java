package fr.eni.demo.bo;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(of = { "immatriculation" })
@ToString
//@Data
//Possible d'utiliser l'annotation @Builder pour produire des API de construction complexe
@SuperBuilder
/**
 * 
 * @author Eni Ecole
 * 
 *         Voici une classe BO (Business Object)
 * 
 *         Respectant le design pattern POJO (Plained Old Java Object)
 * 
 *         Définie avec Lombok
 * 
 *         Elle est maintenant déclarée comme une entité JPA
 */
@Entity
@Table(name = "EMPLOYEE")
@Inheritance(strategy = InheritanceType.JOINED)
//@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
//@DiscriminatorColumn(name = "DISCR")
//@DiscriminatorValue(value = "E")
public class Employe {
	// Attributs
	// Clef primaire -- gestion par IDENTITY
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	// Clef primaire -- gestion par TABLE
	// @GeneratedValue(strategy = GenerationType.TABLE)
	@Id
	@Column(name = "EMPLOYEE_ID")
	private Integer id;

	// Ajout de l'association ManyToOne
	@ManyToOne
	@JoinColumn(name = "CIVILITY_ID")
	@NotNull(message = "{employee.civility.error}")
	private Civilite civilite;

	// Précision sur le nom de la colonne : name=
	// Cette colonne est non nulle -> nullable = false
	// La taille de la colonne en base est de 90 -> length = 90
	@Column(name = "LAST_NAME", nullable = false, length = 90)
	@NotBlank(message = "{employee.ln.blank-error}")
	@Size(max = 90, message = "{employee.ln.size-error}")
	private String nom;

	@Column(name = "FIRST_NAME", nullable = false, length = 150)
	@NotBlank(message = "{employee.fn.blank-error}")
	@Size(max = 150, message = "{employee.fn.size-error}")
	private String prenom;

	// La valeur de l'email est unique -> unique = true
	@Column(nullable = false, unique = true, length = 255)
	@NotBlank(message = "{employee.email.blank-error}")
	@Size(max = 255, message = "{employee.email.size-error}")
	private String email;

	@Column(name = "EMPLOYEE_REGISTRATION", nullable = false, unique = true, length = 100)
	@NotBlank(message = "{employee.registration.blank-error}")
	@Size(max = 100, message = "{employee.registration.size-error}")
	private String immatriculation;

	@Column(name = "HOME_PHONE_NUMBER", length = 12)
	private String numDom;

	@Column(name = "CELL_NUMBER", length = 12)
	private String numPortable;

	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@JoinColumn(name = "ADDRESS_ID")
	@NotNull(message = "{employee.address.error}")
	private Adresse adresse;
}
