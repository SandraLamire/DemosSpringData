package fr.eni.demo.bo.accompagement;

import fr.eni.demo.bo.Employe;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
@SuperBuilder
/**
 * 
 * @author Eni Ecole
 */
@Entity
@Table(name = "SCHOOL_BUSINESS_OFFICER")
//@DiscriminatorValue(value = "C")
public class ChargeRelationsEcoleEntreprises extends Employe {
	@Column(name = "OFFICE_PHONE_NUMBER", length = 12)
	private String numeroBureau;
}
