package fr.eni.demo.bo.formation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Entity
@Table(name = "COMPUTER_COURSE")
public class Cours {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "COMPUTER_COURSE_ID")
	private Integer id;

	@Column(name = "COMPUTER_SCIENCE_COURSE", length = 150)
	private String filiere;
	
	@Column(name = "REFERENCE", unique = true, length = 15)
	private String reference;
	
	@Column(name = "TITLE", length = 250)
	private String titre;
	
	@Column(name = "DURATION")
	private int duree;
}
