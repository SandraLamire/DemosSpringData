package fr.eni.demo.bo.pk2;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Embeddable
public class EtudiantPK2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(nullable = false, unique = true, length = 255)
	private String email;

	@Column(name = "STUDENT_REGISTRATION", nullable = false, unique = true, length = 100)
	private String immatriculation;
}
