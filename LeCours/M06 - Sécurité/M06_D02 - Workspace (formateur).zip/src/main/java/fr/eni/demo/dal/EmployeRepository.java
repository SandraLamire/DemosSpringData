package fr.eni.demo.dal;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import fr.eni.demo.bo.Employe;

public interface EmployeRepository extends JpaRepository<Employe, Integer> {

	// Création d'une requête paramétrée avec JPQL
	@Query("SELECT e FROM Employe e WHERE e.email = :email")
	Employe findByEmailWithJPQL(@Param("email") String email);

	// Méthodes de requêtes avec mots clefs via Spring Data JPA
	Employe findByImmatriculation(@Param("immatriculation") String immatriculation);

	// Méthodes de requêtes avec mots clefs via Spring Data JPA
	List<Employe> findByOrderByCivilite();

}
