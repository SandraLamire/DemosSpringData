package fr.eni.demo.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.pk.Etudiant;
import fr.eni.demo.bo.pk.EtudiantPK;

public interface EtudiantRepository extends JpaRepository<Etudiant, EtudiantPK>{

}
