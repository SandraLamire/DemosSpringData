package fr.eni.demo.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.stagiaire.Promo;

public interface PromoRepository extends JpaRepository<Promo, Integer> {

}
