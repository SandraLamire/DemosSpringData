package fr.eni.demo.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import lombok.AllArgsConstructor;

@ControllerAdvice
@AllArgsConstructor
public class AppExceptionHandler {

	private final MessageSource messageSource;

	// Préciser les exceptions à gérer
//	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<String> capturerException(Exception ex) {
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_ACCEPTABLE);
	}

	// Gestion des exceptions de validation - MethodArgumentNotValidException
//	@ExceptionHandler(value = { MethodArgumentNotValidException.class })
	public ResponseEntity<String> capturerMethodArgumentNotValidException(MethodArgumentNotValidException ex,
			Locale locale) {
		final String titreMsg = messageSource.getMessage("notvalidexception", null, locale);

		String message = ex
				.getFieldErrors()
				.stream()
				.map(e -> e.getDefaultMessage())
				.reduce(titreMsg, String::concat);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
	}
}
