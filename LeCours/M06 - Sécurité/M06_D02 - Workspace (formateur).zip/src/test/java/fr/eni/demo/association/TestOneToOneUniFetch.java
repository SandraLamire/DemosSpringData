package fr.eni.demo.association;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import fr.eni.demo.bo.Adresse;
import fr.eni.demo.bo.Employe;
import fr.eni.demo.dal.EmployeRepository;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class TestOneToOneUniFetch {	
	@Autowired
	EmployeRepository repository;
	
	Adresse adresse ;	
	Employe employe ;
	

	@BeforeEach
	public void test_save() {
		adresse = Adresse
				.builder()
				.rue("15 rue de Paris")
				.codePostal("35000")
				.ville("Rennes")
				.build();
		
		employe = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();
		
		//Association
		employe.setAdresse(adresse);
		
		// Appel du comportement
		final Employe employeDB = repository.save(employe);
		log.info(employeDB.toString());

		// Vérification de l'identifiant de l'employé
		assertThat(employeDB.getId()).isGreaterThan(0);
		
		//Vérification de la cascade de l'association
		assertThat(adresse.getId()).isGreaterThan(0);
	}

	//@Transactional -- permet d'avoir un contexte de session
	@Test
	public void test_findById() {
		// Appel du traitement
		int id = employe.getId();
		final Optional<Employe> op = repository.findById(id);
		// Vérification que l'Optional contienne une entité
		assertThat(op.isPresent()).isTrue();
		// Récupération de l'entité
		final Employe employeDB = op.get();
		// Validation de l'entité
		assertThat(employeDB.getId()).isEqualTo(id);
		assertThat(employeDB.getImmatriculation()).isEqualTo(employe.getImmatriculation());
		
		assertThat(employeDB.getAdresse()).isNotNull();
		Adresse adresseDB = employeDB.getAdresse();
		assertThat(adresseDB.getId()).isGreaterThan(0);
		assertThat(adresseDB.getCodePostal()).isNotNull();
		assertThat(adresseDB.getCodePostal()).isEqualTo(adresse.getCodePostal());
	}
}