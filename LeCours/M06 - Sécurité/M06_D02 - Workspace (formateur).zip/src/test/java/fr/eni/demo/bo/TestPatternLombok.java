package fr.eni.demo.bo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
@TestMethodOrder(MethodOrderer.MethodName.class)
public class TestPatternLombok {
	@Test
	void test01_patternBuilder_TousLesAttributs() {

		Employe annelise = Employe
					.builder()
					.nom("BAILLE")
					.prenom("Anne-Lise")
					.email("abaille@campus-eni.fr")
					.immatriculation("ENI_Ecole_012892")
					.numDom("0299XXXXXX")
					.numPortable("0699XXXXXX")
					.build();
		log.info(annelise.toString());		
		assertThat(annelise.getNom()).isEqualTo("BAILLE"); 
		assertThat(annelise.getImmatriculation()).isEqualTo("ENI_Ecole_012892");
		assertThat(annelise.getNumDom()).isEqualTo("0299XXXXXX");
		assertThat(annelise.getNumPortable()).isEqualTo("0699XXXXXX");
	}
	
	@Test
	void test02_patternBuilder_QuelquesAttributs() {
		Employe stephane = Employe
				.builder()
				.nom("GOBIN")
				.prenom("Stéphane")
				.email("sgobin@campus-eni.fr")
				.immatriculation("ENI_Ecole_011112")
				.numDom("0288XXXXXX")
				.build();
		log.info(stephane.toString());		
		assertThat(stephane.getNom()).isEqualTo("GOBIN");
		assertThat(stephane.getImmatriculation()).isEqualTo("ENI_Ecole_011112");
		assertThat(stephane.getNumDom()).isEqualTo("0288XXXXXX");
		assertNull(stephane.getNumPortable());
	}
}
