package fr.eni.demo.dal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.Employe;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestEmployeRepository {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EmployeRepository repository;

	@Test
	public void test_save() {
		final Employe entiteASauver = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Appel du comportement
		final Employe entite = repository.save(entiteASauver);
		log.info(entite.toString());

		// Vérification de l'identifiant de l'employé
		assertThat(entite.getId()).isGreaterThan(0);
	}

	@Test
	public void test_findById() {
		// Contexte de la DB
		final Employe entite = Employe
				.builder()
				.nom("DAUTAIS")
				.prenom("Servane")
				.email("sdautais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_09397")
				.numPortable("06XXXXXXXX")
				.build();

		// Contexte de la DB
		entityManager.persist(entite);
		entityManager.flush();
		log.info(entite.toString());
		assertThat(entite.getId()).isGreaterThan(0);

		// Appel du traitement
		int id = entite.getId();
		final Optional<Employe> op = repository.findById(id);
		// Vérification que l'Optional contienne une entité
		assertThat(op.isPresent()).isTrue();
		// Récupération de l'entité
		final Employe entiteDB = op.get();
		log.info(entiteDB.toString());
		// Validation de l'entité
		assertThat(entiteDB.getId()).isEqualTo(id);
		assertThat(entiteDB).isEqualTo(entite);
	}

	@Test
	public void test_update() {
		// Contexte de la DB
		final Employe entite = Employe
				.builder()
				.nom("LACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_15009")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build();

		// Contexte de la DB
		entityManager.persist(entite);
		entityManager.flush();
		assertThat(entite.getId()).isGreaterThan(0);
		log.info("ORIGINE : " + entite.toString());

		entite.setNom("DELACHESNAIS");

		// Appel du traitement
		final Employe entiteDB = repository.save(entite);
		assertThat(entiteDB.getId()).isEqualTo(entite.getId());
		assertThat(entiteDB.getNom()).isEqualTo(entite.getNom());
		log.info("MISE A JOUR : " + entiteDB.toString());
	}

	@Test
	public void test_delete() {
		final Employe entite = Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build();

		// Contexte de la DB
		entityManager.persist(entite);
		entityManager.flush();
		log.info(entite.toString());
		assertThat(entite.getId()).isGreaterThan(0);

		// Appel du comportement
		repository.delete(entite);

		// Vérification que l'entité a été supprimée
		Employe entityDB = entityManager.getEntityManager().find(Employe.class, entite.getId());
		assertNull(entityDB);
	}

	// Vérifier que s’il n’y a pas d’enregistrement en base, nous remontons vide
	@Test
	public void test_find_all_is_empty() {
		final List<Employe> lstEntites = repository.findAll();
		assertThat(lstEntites).isEmpty();
	}

	// Retrouver l’ensemble du jeu de données
	@Test
	public void test_findAll() {
		// Contexte de la DB
		jeuDeDonnees();

		final List<Employe> lstEntites = repository.findAll();
		assertThat(lstEntites.size()).isGreaterThan(0);
		log.info(lstEntites.toString());
	}

	// Création d’un jeu de données pour simuler la base
	private void jeuDeDonnees() {
		final List<Employe> lstEntites = new ArrayList<>();
		lstEntites.add(Employe
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build());
		lstEntites.add(Employe
				.builder()
				.nom("DAUTAIS")
				.prenom("Servane")
				.email("sdautais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_09397")
				.numPortable("06XXXXXXXX")
				.build());
		lstEntites.add(Employe
				.builder()
				.nom("DELACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_15009")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build());

		// Contexte de la DB
		lstEntites.forEach(e -> {
			entityManager.persist(e);
		});
		entityManager.flush();
	}
}
