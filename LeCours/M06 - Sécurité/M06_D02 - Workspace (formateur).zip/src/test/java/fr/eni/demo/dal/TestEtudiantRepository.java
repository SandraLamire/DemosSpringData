package fr.eni.demo.dal;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.pk.Etudiant;
import fr.eni.demo.bo.pk.EtudiantPK;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestEtudiantRepository {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EtudiantRepository repository;

	@Test
	public void test_save() {
		final Etudiant entiteASauver = Etudiant
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.email("csoprano@campus-eni.fr")
				.immatriculation("ENI_CAMPUS_202311872")
				.numDom("02XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();
		
		// Appel du comportement
		final Etudiant entite = repository.save(entiteASauver);
		assertThat(entite).isNotNull();		
		log.info(entite.toString());

		final EtudiantPK pk = EtudiantPK
				.builder()
				.email(entiteASauver.getEmail())
				.immatriculation(entiteASauver.getImmatriculation())
				.build();
		final Etudiant entiteDB = entityManager.find(Etudiant.class, pk);
		assertThat(entiteDB).isNotNull();
		assertThat(entite).isEqualTo(entiteDB);
	}

}
