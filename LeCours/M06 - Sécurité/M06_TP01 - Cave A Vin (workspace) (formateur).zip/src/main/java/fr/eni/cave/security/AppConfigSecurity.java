package fr.eni.cave.security;

import javax.sql.DataSource;

import org.apache.commons.logging.*;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.provisioning.*;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class AppConfigSecurity {
	protected final Log logger = LogFactory.getLog(getClass());

	/**
	 * Récupération des utilisateurs de l'application via la base de données
	 */
	@Bean
	UserDetailsManager userDetailsManager(DataSource dataSource) {
		JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager(dataSource);
		jdbcUserDetailsManager.setUsersByUsernameQuery("select login, password, 1 from cav_user where login=?");
		jdbcUserDetailsManager.setAuthoritiesByUsernameQuery("select login, authority from cav_user where login=?");

		return jdbcUserDetailsManager;
	}

	/**
	 * Restriction des URLs selon la connexion utilisateur et leurs rôles
	 */
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests(auth -> {
			auth
					// Consulter le stock des bouteilles - est accessible à tout le monde
					.requestMatchers("/caveavin/bouteilles").permitAll()

					// Permettre aux rôles CLIENT et OWNER de manipuler :
					.requestMatchers(HttpMethod.GET, "/caveavin/paniers/**").hasAnyRole("CLIENT", "OWNER")
					.requestMatchers(HttpMethod.GET, "/caveavin/paniers/client/actifs/**").hasAnyRole("CLIENT", "OWNER")
					.requestMatchers(HttpMethod.GET, "/caveavin/paniers/client/commandes/**").hasAnyRole("CLIENT", "OWNER")
					
					// Restreindre au rôle CLIENT
					.requestMatchers(HttpMethod.POST, "/caveavin/paniers").hasRole("CLIENT")
					.requestMatchers(HttpMethod.PUT, "/caveavin/paniers").hasRole("CLIENT")

					// Restreindre au rôle OWNER
					.requestMatchers(HttpMethod.GET, "/caveavin/bouteilles/**").hasRole("OWNER")
					.requestMatchers(HttpMethod.POST, "/caveavin/bouteilles").hasRole("OWNER")
					.requestMatchers(HttpMethod.PUT, "/caveavin/bouteilles").hasRole("OWNER")
					.requestMatchers(HttpMethod.DELETE, "/caveavin/bouteilles").hasRole("OWNER")

					// Toutes autres url et méthodes HTTP ne sont pas permises
					.anyRequest().denyAll();
		});
		// Use Http Basic Authentication
		http.httpBasic(Customizer.withDefaults());

		// Désactivé Cross Site Request Forgery
		// Non préconisé pour les API REST en stateless. 
		// Sauf pour POST, PUT, PATCH et DELETE
		http.csrf(csrf -> {
			csrf.disable();
		});

		return http.build();
	}

}
