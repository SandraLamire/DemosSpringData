USE CAVE_A_VIN
GO

DROP TABLE cav_line;
DROP TABLE cav_shopping_cart;
DROP TABLE cav_bottle;
DROP TABLE cav_region;
DROP TABLE cav_color;
DROP TABLE cav_owner;
DROP TABLE cav_client;
DROP TABLE cav_user;
DROP TABLE cav_address;