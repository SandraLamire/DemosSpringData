--Supprime la table si elle existe
DROP TABLE [Users];

--Crée la table Users
CREATE TABLE [users](
	[pseudo] [VARCHAR](250) PRIMARY KEY,
	[password] [VARCHAR](68) NOT NULL,
	[authority] [VARCHAR](15) NOT NULL);

-- ENREGISTREMENTS :
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('abaille@campus-eni.fr','{bcrypt}$2a$10$KaSHgvH9p/cUnsOVPzYvzunWDAIv68whrOxmui1S.0AjzbP5RX7yO','ROLE_EMPLOYE');/*Mot de Passe = annelise*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('fdelachesnais@campus-eni.fr','{bcrypt}$2a$10$xi0DX528CfMALBQFZwz0huY4LbGJAIjsE7/h14WFUVnJepdpN3/qK','ROLE_EMPLOYE');/*Mot de Passe = frédéric*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('sdautais@campus-eni.fr','{bcrypt}$2a$10$qHGnMJYcTx1Vr.UTpnD.OuZHTbRS0O0N6SSn2BZMVbFekKOgjHTvu','ROLE_EMPLOYE');/*Mot de Passe = servane*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('sgobin@campus-eni.fr','{bcrypt}$2a$10$TJKLPQ0sEu./Q6Z0b9UdkOG5T26XSKRNs1ZPNkzu4dj12Dad9r8eS','ROLE_EMPLOYE');/*Mot de Passe = stéphane*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('cnicolas@campus-eni.fr','{bcrypt}$2a$10$lI2pcoTCeqEWCyg1rmSGfO52xwAQ2zuFjfuEVcV2ydCiBMV.DMSGC','ROLE_ADMIN');/*Mot de Passe = cédric*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('epageot@campus-eni.fr','{bcrypt}$2a$10$g4r5pFMACqXyd6GWXgJJru1T.MQfEUhpMLtaTsZNZIVDjd2/eBtbW','ROLE_EMPLOYE');/*Mot de Passe = emma*/
INSERT INTO [USERS] ([pseudo],[password],[authority]) VALUES ('hbernard@campus-eni.fr','{bcrypt}$2a$10$CizK.V5lOQa/z1muRjDj9e.AIXh1ULG/hg2NW/alzn08y0tsS0WEO','ROLE_EMPLOYE');/*Mot de Passe = hervé*/