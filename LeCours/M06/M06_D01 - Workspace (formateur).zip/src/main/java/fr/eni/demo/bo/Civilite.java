package fr.eni.demo.bo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Entity
@Table(name = "CIVILITY")
public class Civilite {

	@Id
	@Column(name = "CIVILITY_ID", length = 3)
	private String clef;

	@Column(name = "LABEL", unique = true, length = 50)
	private String libelle;
}
