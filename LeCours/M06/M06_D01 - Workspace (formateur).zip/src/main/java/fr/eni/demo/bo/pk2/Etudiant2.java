package fr.eni.demo.bo.pk2;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
/**
 * 
 * @author Eni Ecole
 * 
 * @category Voici une entité avec une clef composite correspondant à l'email et
 *           l'immatriculation
 */
@Entity
@Table(name = "STUDENT2")
public class Etudiant2 {
	//Définir l'attribut de la clef composite	
	@EmbeddedId
	private EtudiantPK2 pk;

	@Column(name = "LAST_NAME", nullable = false, length = 90)
	private String nom;

	@Column(name = "FIRST_NAME", nullable = false, length = 150)
	private String prenom;

	@Column(name = "HOME_PHONE_NUMBER", length = 12)
	private String numDom;

	@Column(name = "CELL_NUMBER", length = 12)
	private String numPortable;
	
	@Column(name="PERSONAL_EMAIL", nullable = false, unique = true, length = 255)
	private String emailPersonnel;
}
