package fr.eni.demo.dal.formation;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import fr.eni.demo.bo.formation.Cours;

public interface CoursRepository extends JpaRepository<Cours, Integer> {

	// Création d'une requête avec JPQL
	@Query("SELECT c FROM Cours c WHERE c.filiere = 'Développement'")
	List<Cours> findWithJPQL();

	// Création d'une requête native - SQL
	@Query(value = "SELECT c.* FROM COMPUTER_COURSE c WHERE c.COMPUTER_SCIENCE_COURSE like '%Réseau%'", nativeQuery = true)
	List<Cours> findWithSQL();
}
