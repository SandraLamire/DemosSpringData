package fr.eni.demo.dal.formation;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.eni.demo.bo.formation.Formateur;

public interface FormateurRepository extends JpaRepository<Formateur, Integer>{

}
