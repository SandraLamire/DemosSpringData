package fr.eni.demo.security;

import javax.sql.DataSource;

import org.apache.commons.logging.*;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.provisioning.*;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class EniSecurityConfig {
	protected final Log logger = LogFactory.getLog(getClass());
	/**
	* Récupération des utilisateurs de l'application via la base de données
	*/
	@Bean
	UserDetailsManager userDetailsManager(DataSource dataSource) {
		JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager(dataSource);
		jdbcUserDetailsManager.setUsersByUsernameQuery("select pseudo, password, 1 from users where pseudo=?");
		jdbcUserDetailsManager.setAuthoritiesByUsernameQuery("select pseudo, authority from users where pseudo=?");

		return jdbcUserDetailsManager;
	}
	

	/**
	* Restriction des URLs selon la connexion utilisateur et leurs rôles
	*/
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http.authorizeHttpRequests(auth -> {
			auth
			//Permettre l'accès à l'URL racine à tout le monde
			.requestMatchers("/eniecole").permitAll()
			//Permettre aux rôles EMPLOYE et ADMIN de manipuler les URLs en GET
			.requestMatchers(HttpMethod.GET, "/eniecole/employes/**").hasAnyRole("EMPLOYE","ADMIN")
			//Restreindre la manipulation des méthodes POST, PUT, PATCH et DELETE au rôle ADMIN
			.requestMatchers(HttpMethod.POST, "/eniecole/employes").hasRole("ADMIN")
			.requestMatchers(HttpMethod.PUT, "/eniecole/employes").hasRole("ADMIN")
			.requestMatchers(HttpMethod.PATCH, "/eniecole/employes").hasRole("ADMIN")
			.requestMatchers(HttpMethod.DELETE, "/eniecole/employes").hasRole("ADMIN")
			//Toutes autres url et méthodes HTTP ne sont pas permises
			.anyRequest().denyAll();
		});
		//Use Http Basic Authentication
		http.httpBasic(Customizer.withDefaults());

		//Désactivé Cross Site Request Forgery
		// Non préconisé pour les API REST en stateless. Sauf pour POST, PUT, PATCH et DELETE
		http.csrf(csrf -> {
			csrf.disable();
		});
		
		return http.build();
	}

}
