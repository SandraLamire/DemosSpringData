package fr.eni.demo.JPQL;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.Civilite;
import fr.eni.demo.bo.Employe;
import fr.eni.demo.bo.accompagement.ChargeRelationsEcoleEntreprises;
import fr.eni.demo.bo.formation.Cours;
import fr.eni.demo.bo.formation.Formateur;
import fr.eni.demo.dal.EmployeRepository;
import fr.eni.demo.dal.formation.CoursRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestJPQLMethodesRequetes {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EmployeRepository employeRepository;

	@Autowired
	CoursRepository coursRepository;

	@BeforeEach
	public void jeuDeDonnees() {
		Civilite monsieur = Civilite
				.builder()
				.clef("M")
				.libelle("Monsieur")
				.build();

		Civilite madame = Civilite
				.builder()
				.clef("Mme")
				.libelle("Madame")
				.build();

		Civilite mx = Civilite
				.builder()
				.clef("Mx")
				.libelle("Mix")
				.build();

		entityManager.persist(monsieur);
		entityManager.persist(madame);
		entityManager.persist(mx);

		List<Employe> employes = new ArrayList<>();
		employes.add(Employe
				.builder()
				.civilite(monsieur)
				.nom("NICOLAS")
				.prenom("Cédric")
				.email("cnicolas@campus-eni.fr")
				.immatriculation("ENI_ECOLE_10100")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build());

		employes.add(Formateur
				.builder()
				.civilite(madame)
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.filiere("Développement")
				.build());

		employes.add(Formateur
				.builder()
				.civilite(mx)
				.nom("DELACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_14398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.filiere("Développement")
				.build());

		employes.add(Formateur
				.builder()
				.civilite(monsieur)
				.nom("MATHIEU")
				.prenom("Wilfrid")
				.email("wmathieu@campus-eni.fr")
				.immatriculation("ENI_ECOLE_14388")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.filiere("Système et Réseau")
				.build());

		employes.add(ChargeRelationsEcoleEntreprises
				.builder()
				.civilite(mx)
				.nom("PAGEOT")
				.prenom("Emma")
				.email("epageot@campus-eni.fr")
				.immatriculation("ENI_ECOLE_13398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.numeroBureau("04XXXXXXXX")
				.build());

		employes.forEach(e -> {
			entityManager.persist(e);
			// Vérification de l'identifiant
			assertThat(e.getId()).isGreaterThan(0);
		});

		List<Cours> listeCoursDB = new ArrayList<>();
		listeCoursDB.add(Cours
				.builder()
				.filiere("Développement")
				.reference("DEV2023-M030")
				.titre("Web Client HTML CSS")
				.duree(5)
				.build());
		listeCoursDB.add(Cours
				.builder()
				.filiere("Développement")
				.reference("DEV2023-M310")
				.titre("Framework JS Angular")
				.duree(5)
				.build());
		listeCoursDB.add(Cours
				.builder()
				.filiere("Développement")
				.reference("DEV2023-M360")
				.titre("Java Frameworks - APIs Web")
				.duree(10)
				.build());
		listeCoursDB.add(Cours
				.builder()
				.filiere("Système et Réseau")
				.reference("TSRR-120")
				.titre("Bases des réseaux")
				.duree(5)
				.build());
		listeCoursDB.add(Cours
				.builder()
				.filiere("Système et Réseau")
				.reference("TSRR-170")
				.titre("GLPI")
				.duree(5)
				.build());

		listeCoursDB.forEach(c -> {
			entityManager.persist(c);
			// Vérification de l'identifiant
			assertThat(c.getId()).isGreaterThan(0);
		});
	}

	@Test
	public void test_requete_JPQL() {
		final List<Cours> listeCoursDev = coursRepository.findWithJPQL();

		// Vérification
		assertThat(listeCoursDev).isNotNull();
		assertThat(listeCoursDev).isNotEmpty();
		assertThat(listeCoursDev.size()).isEqualTo(3);
	}

	@Test
	public void test_requete_JPQL_parametree() {
		final String email = "epageot@campus-eni.fr";
		final Employe employe = employeRepository.findByEmailWithJPQL(email);

		// Vérification
		assertThat(employe).isNotNull();
		assertThat(employe.getNom()).isNotNull();
		assertThat(employe.getNom()).isEqualTo("PAGEOT");
	}

	@Test
	public void test_methode_requete_findByImmatriculation() {
		final String immatriculation = "ENI_ECOLE_14388";
		final Employe employe = employeRepository.findByImmatriculation(immatriculation);

		// Vérification
		assertThat(employe).isNotNull();
		assertThat(employe.getNom()).isNotNull();
		assertThat(employe.getNom()).isEqualTo("MATHIEU");
	}

	@Test
	public void test_methode_requete_findByOrderByCivilite() {
		final List<Employe> employes = employeRepository.findByOrderByCivilite();

		// Vérification
		assertThat(employes).isNotNull();
		assertThat(employes).isNotEmpty();
		log.info(employes.toString());
	}

	@Test
	public void test_requete_native_SQL() {
		final List<Cours> coursReseaux = coursRepository.findWithSQL();

		// Vérification
		assertThat(coursReseaux).isNotNull();
		assertThat(coursReseaux).isNotEmpty();
		assertThat(coursReseaux.size()).isEqualTo(2);
	}
}
