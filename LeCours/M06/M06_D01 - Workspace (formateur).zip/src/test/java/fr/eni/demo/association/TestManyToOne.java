package fr.eni.demo.association;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.Civilite;
import fr.eni.demo.bo.Employe;
import fr.eni.demo.dal.CiviliteRepository;
import fr.eni.demo.dal.EmployeRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestManyToOne {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	CiviliteRepository civiliteRepository;

	@Autowired
	EmployeRepository employeRepository;

	private Civilite monsieur;
	private Civilite madame;
	private Civilite mx;// Non binaire

	@BeforeEach
	public void initCivilite() {
		monsieur = Civilite
				.builder()
				.clef("M")
				.libelle("Monsieur")
				.build();

		madame = Civilite
				.builder()
				.clef("Mme")
				.libelle("Madame")
				.build();

		mx = Civilite
				.builder()
				.clef("Mx")
				.libelle("Mix")
				.build();

		civiliteRepository.save(monsieur);
		civiliteRepository.save(madame);
		civiliteRepository.save(mx);
	}

	@Test
	public void test_save() {
		final Employe employe = Employe
				.builder()
				.nom("DELACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_14398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build();

		// Association ManyToOne
		employe.setCivilite(mx);

		// Appel du comportement
		final Employe employeDB = employeRepository.save(employe);
		// Vérification de l'identifiant de l'employé
		assertThat(employeDB.getId()).isGreaterThan(0);

		// Vérification de sa civilité
		assertThat(employeDB.getCivilite()).isNotNull();
		assertThat(employeDB.getCivilite()).isEqualTo(mx);
		log.info(employeDB.toString());
	}

	@Test
	public void test_findAll() {
		List<Employe> employes = jeuDeDonnees();

		// sauver le jeu de données en base
		employes.forEach(emp -> {
			entityManager.persist(emp);
			assertThat(emp.getId()).isGreaterThan(0);
		});

		// Appel du comportement
		final List<Employe> employesDB = employeRepository.findAll();
		// Vérification de l'identifiant des employés
		employesDB.forEach(emp -> {
			assertThat(emp.getId()).isGreaterThan(0);

			// Vérification de la civilité
			assertThat(emp.getCivilite()).isNotNull();
		});
	}

	@Test
	public void test_delete() {
		final Employe employe = Employe
				.builder()
				.nom("DELACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_14398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build();

		// Association ManyToOne
		employe.setCivilite(mx);

		// Contexte de la DB
		final Employe employeDB = entityManager.persist(employe);
		entityManager.flush();
		assertThat(employeDB.getId()).isGreaterThan(0);
		assertThat(employeDB.getCivilite()).isNotNull();
		assertThat(employeDB.getCivilite()).isEqualTo(mx);

		// Appel du comportement
		employeRepository.delete(employeDB);

		// Vérification que l'entité a été supprimée
		final Employe employeDB2 = entityManager.find(Employe.class, employeDB.getId());
		assertNull(employeDB2);

		// Vérifier que tous les civilités sont toujours présentes - PAS de cascade
		final List<Civilite> civilites = civiliteRepository.findAll();
		assertThat(civilites).isNotNull();
		assertThat(civilites).isNotEmpty();
		log.info(civilites.toString());
		assertThat(civilites.size()).isEqualTo(3);
	}

	private List<Employe> jeuDeDonnees() {
		List<Employe> employes = new ArrayList<>();
		employes.add(Employe
				.builder()
				.civilite(madame)
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.build());
		employes.add(Employe
				.builder()
				.civilite(mx)
				.nom("DELACHESNAIS")
				.prenom("Frédéric")
				.email("fdelachesnais@campus-eni.fr")
				.immatriculation("ENI_ECOLE_14398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build());
		employes.add(Employe
				.builder()
				.civilite(monsieur)
				.nom("NICOLAS")
				.prenom("Cédric")
				.email("cnicolas@campus-eni.fr")
				.immatriculation("ENI_ECOLE_10100")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build());
		return employes;
	}
}
