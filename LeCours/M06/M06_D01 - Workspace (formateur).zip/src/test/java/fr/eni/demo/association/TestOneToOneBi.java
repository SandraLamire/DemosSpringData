package fr.eni.demo.association;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.*;

import fr.eni.demo.bo.stagiaire.*;
import fr.eni.demo.dal.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestOneToOneBi {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EtudiantEniRepository etudiantEniRepository;

	@Autowired
	DonneesPersoRepository donneesPersoRepository;

	@Test
	public void test_save() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();

		// Association bidirectionnelle - il faut associer des 2 côtés
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Appel du comportement
		final EtudiantEni etudiantDB = etudiantEniRepository.save(etudiant);
		//log.info(etudiant.toString());
		log.info(etudiantDB.toString());

		// Vérification de l'identifiant
		assertThat(etudiantDB.getImmatriculation()).isEqualTo(immatriculation);

		// Vérification de la cascade de l'association
		assertThat(etudiantDB.getDonneesPerso().getId()).isGreaterThan(0);
	}

	@Test
	public void test_save_donneesPerso() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();

		// Association bidirectionnelle - il faut associer des 2 côtés
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Appel du comportement
		final DonneesPerso donneesPersoDB = donneesPersoRepository.save(donneesPerso);

		// Vérification de l'identifiant
		assertThat(donneesPersoDB.getId()).isGreaterThan(0);

		// Vérification de la cascade de l'association
		final EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, immatriculation);
		assertThat(etudiantDB).isNotNull();
		assertThat(etudiantDB.getImmatriculation()).isEqualTo(immatriculation);

		// Trace l'entité principale
		log.info(etudiant.toString());
	}

	@Test
	public void test_delete() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();

		// Association bidirectionnelle - il faut associer des 2 côtés
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Contexte de la DB
		entityManager.persist(etudiant);
		entityManager.flush();
		
		// Appel du comportement
		etudiantEniRepository.delete(etudiant);

		// Vérification que l'entité a été supprimée
		EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, immatriculation);
		assertNull(etudiantDB);
		DonneesPerso donneesPersoDB = entityManager.find(DonneesPerso.class, donneesPerso.getId());
		assertNull(donneesPersoDB);
	}

	@Test
	public void test_delete_donneesPerso() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();
		
		// Association bidirectionnelle - il faut associer des 2 côtés
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Contexte de la DB
		entityManager.persist(etudiant);
		entityManager.flush();
		
		// Appel du comportement
		donneesPersoRepository.delete(donneesPerso);

		// Vérification que l'entité a été supprimée
		DonneesPerso donneesPersoDB = entityManager.find(DonneesPerso.class, donneesPerso.getId());
		assertNull(donneesPersoDB);
		EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, immatriculation);
		assertNull(etudiantDB);
	}

	@Test
	public void test_orphanRemoval() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();

		// Association
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Contexte de la DB
		entityManager.persist(etudiant);
		entityManager.flush();
		
		// Supprimer le lien entre l'entité EtudiantEni et l'entité DonneesPerso
		etudiant.setDonneesPerso(null);

		// Appel du comportement
		etudiantEniRepository.delete(etudiant);

		// Vérification que l'entité a été supprimée
		EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, immatriculation);
		assertNull(etudiantDB);

		DonneesPerso donneesPersoDB = entityManager.find(DonneesPerso.class, donneesPerso.getId());
		assertNull(donneesPersoDB);
	}

	@Test
	public void test_orphanRemoval_donneesPerso() {
		final String immatriculation = "ENI_CAMPUS_202311872";

		final DonneesPerso donneesPerso = DonneesPerso
				.builder()
				.nom("SOPRANO")
				.prenom("Camille")
				.numDom("02XXXXXXXX")
				.numPortable("07XXXXXXXX")
				.emailPersonnel("camille.soprano@perso.fr")
				.build();

		final EtudiantEni etudiant = EtudiantEni
				.builder()
				.immatriculation(immatriculation)
				.email("csoprano@campus-eni.fr")
				.build();

		// Association
		etudiant.setDonneesPerso(donneesPerso);
		donneesPerso.setEtudiantEni(etudiant);

		// Contexte de la DB
		entityManager.persist(etudiant);
		entityManager.flush();
	
		// Supprimer le lien entre l'entité DonneesPerso et l'entité EtudiantEni
		donneesPerso.setEtudiantEni(null);

		// Appel du comportement
		donneesPersoRepository.delete(donneesPerso);

		// Vérification que l'entité a été supprimée
		DonneesPerso donneesPersoDB = entityManager.find(DonneesPerso.class, donneesPerso.getId());
		assertNull(donneesPersoDB);

		EtudiantEni etudiantDB = entityManager.find(EtudiantEni.class, immatriculation);
		assertNull(etudiantDB);
	}
}
