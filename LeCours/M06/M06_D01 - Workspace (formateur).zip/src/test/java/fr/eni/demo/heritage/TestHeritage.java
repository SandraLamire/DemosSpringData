package fr.eni.demo.heritage;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import fr.eni.demo.bo.Employe;
import fr.eni.demo.bo.accompagement.ChargeRelationsEcoleEntreprises;
import fr.eni.demo.bo.formation.Formateur;
import fr.eni.demo.dal.EmployeRepository;
import fr.eni.demo.dal.accompagement.ChargeReeRepository;
import fr.eni.demo.dal.formation.FormateurRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@DataJpaTest
public class TestHeritage {
	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	EmployeRepository employeRepository;

	@Autowired
	FormateurRepository formateurRepository;

	@Autowired
	ChargeReeRepository chargeReeRepository;

	@BeforeEach
	public void jeuDeDonnees() {
		List<Employe> employes = new ArrayList<>();
		employes.add(Employe
				.builder()
				.nom("NICOLAS")
				.prenom("Cédric")
				.email("cnicolas@campus-eni.fr")
				.immatriculation("ENI_ECOLE_10100")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.build());

		employes.add(Formateur
				.builder()
				.nom("BAILLE")
				.prenom("Anne-Lise")
				.email("abaille@campus-eni.fr")
				.immatriculation("ENI_ECOLE_12398")
				.numDom("02XXXXXXXX")
				.filiere("Développement")
				.build());

		employes.add(ChargeRelationsEcoleEntreprises
				.builder()
				.nom("PAGEOT")
				.prenom("Emma")
				.email("epageot@campus-eni.fr")
				.immatriculation("ENI_ECOLE_13398")
				.numDom("02XXXXXXXX")
				.numPortable("06XXXXXXXX")
				.numeroBureau("04XXXXXXXX")
				.build());

		// Contexte de la DB
		employes.forEach(e -> {
			entityManager.persist(e);
			// Vérification de l'identifiant
			assertThat(e.getId()).isGreaterThan(0);
		});
	}

	@Test
	public void test_findAll_Employe() {
		final List<Employe> employes = employeRepository.findAll();

		// Vérification
		assertThat(employes).isNotNull();
		assertThat(employes).isNotEmpty();
		assertThat(employes.size()).isEqualTo(3);
		log.info(employes.toString());
	}
	
	@Test
	public void test_findAll_Formateur() {
		final List<Formateur> formateurs = formateurRepository.findAll();

		// Vérification
		assertThat(formateurs).isNotNull();
		assertThat(formateurs).isNotEmpty();
		assertThat(formateurs.size()).isEqualTo(1);
		log.info(formateurs.toString());
	}

	@Test
	public void test_findAll_ChargeRee() {
		final List<ChargeRelationsEcoleEntreprises> chargesRee = chargeReeRepository.findAll();

		// Vérification
		assertThat(chargesRee).isNotNull();
		assertThat(chargesRee).isNotEmpty();
		assertThat(chargesRee.size()).isEqualTo(1);
		log.info(chargesRee.toString());
	}
}
