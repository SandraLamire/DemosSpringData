package fr.eni.cave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaveAVinApplicationTests {

	@Test
	void contextLoads() {
	}

}
