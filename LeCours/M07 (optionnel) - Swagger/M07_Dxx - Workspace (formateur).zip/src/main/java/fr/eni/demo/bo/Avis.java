package fr.eni.demo.bo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DocumentReference;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder


@Document(collection = "reviews")
public class Avis {
	@Id
	private String id;

	@Field(name = "pedagogical_note")
	private int notePedagogie;
	
	@Field(name = "pedagogical_commentary")
	private String commentairePedagogie;
	
	@Field(name = "course_note")
	private int noteCours;
	
	@Field(name = "course_commentary")
	private String commentaireCours;
	
	//Association
	@Field("student")
	private Stagiaire stagiaire;
	
	//Association (N:1)
	@DocumentReference
	@Field("trainer_id")
	private Formateur formateur;
	
	//Association (N:1)
	@DBRef
	@Field("computer_course_id")
	private Cours cours;
}
