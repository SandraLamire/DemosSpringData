package fr.eni.demo.bo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Document(collection = "computer_course")
public class Cours {

	@Id
	private String reference;

	@Field(name = "computer_science_course")
	private String filiere;

	@Field(name = "title")
	private String titre;

	@Field(name = "duration")
	private int duree;
}
