package fr.eni.demo.bo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.*;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Document(collection="trainers")
public class Formateur {
	@Id
	private String email;
	
	@Field(name = "last_name")
	@Indexed(unique = true)
	private String nom;

	@Field(name = "first_name")
	@Indexed(unique = true)
	private String prenom;
}
