package fr.eni.demo.bo;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Stagiaire {
	@Field(name = "student_registration")
	private String immatriculation;
	
	@Field(name = "class_id")
	private String promotion;
}
