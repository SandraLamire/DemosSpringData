package fr.eni.demo.dal;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import fr.eni.demo.bo.Cours;

@RepositoryRestResource(collectionResourceRel = "cours", path = "cours")
public interface CoursRepository extends MongoRepository<Cours, String> {

}
