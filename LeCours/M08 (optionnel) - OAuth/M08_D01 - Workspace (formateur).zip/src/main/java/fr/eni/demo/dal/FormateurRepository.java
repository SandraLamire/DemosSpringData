package fr.eni.demo.dal;

import org.springframework.data.mongodb.repository.MongoRepository;

import fr.eni.demo.bo.Formateur;

public interface FormateurRepository extends MongoRepository<Formateur, String> {

}
