package fr.eni.demo.security.oauth;

import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	/**
	 * il faut être authentifié pour accéder à l'API
	 */
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
				.authorizeHttpRequests(auth -> {
					auth
							// Permettre l'accès à l'URL racine à tout le monde
							.requestMatchers("/").permitAll()
							// Il faut être connecté pour toutes autres URLs
							.anyRequest().authenticated();
				})

				// Indiquer à Spring Security l'utilisation de OAuth 2.0
				.oauth2Login(oauth -> {
				});
		return http.build();
	}
}
