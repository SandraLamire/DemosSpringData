package fr.eni.gestionavis.swagger;
import org.springframework.context.annotation.*;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.info.Info;

@Configuration
@OpenAPIDefinition(info = @Info(
			title = "ENI Gestion d'Avis", 
			description = "Documentation de nos APIs REST avec MongoDB et Spring Data REST", 
			version = "1.0"))
public class OpenApiConfig {
}
