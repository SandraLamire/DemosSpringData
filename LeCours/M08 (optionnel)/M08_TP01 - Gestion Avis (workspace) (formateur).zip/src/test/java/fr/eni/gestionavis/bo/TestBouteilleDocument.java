package fr.eni.gestionavis.bo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import fr.eni.gestionavis.bo.vin.*;
import fr.eni.gestionavis.dal.BouteilleRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class TestBouteilleDocument {

	@Autowired
	BouteilleRepository bouteilleRepository;

	@Test
	void test_save_bouteille() {
		Integer bouteilleId = 2298;
		Bouteille bouteille = Bouteille
				.builder()
				.idBouteille(bouteilleId)
				.idRegion(5)
				.idCouleur(1)
				.nom("Vin Blanc ENI")
				.build();
		bouteilleRepository.save(bouteille);

		// Vérification en base
		Optional<Bouteille> opt = bouteilleRepository.findById(bouteilleId);
		assertThat(opt).isNotNull();
		assertThat(opt.isPresent()).isTrue();

		Bouteille bouteilleDB = opt.get();
		assertThat(bouteilleDB).isNotNull();
		assertThat(bouteilleDB.getNom()).isNotNull();

		log.info(bouteilleDB.toString());
	}
}
