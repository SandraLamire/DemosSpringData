package fr.eni.gestionavis.aop;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class LogAspect {

	@Before("execution(public * *..AvisRepository.findByNote*(int))")
	public void before(JoinPoint jp) {
		log.warn("ENI AOP - @Before - " + jp.getSignature().getName());
	}

	@Around(value = "execution(public * *..AvisRepository.findByNote*(..))")
	public Object around(ProceedingJoinPoint call) throws Throwable {
		Object result = null;
		long before = System.currentTimeMillis();

		result = call.proceed();
		long after = System.currentTimeMillis();
		long duration = after - before;
		String nomMethode = call.getSignature().getDeclaringTypeName() + "/"
				+ call.getSignature().getName();
		log.warn("ENI AOP - @Around - " + nomMethode + ":" + duration + " ms");
		return result;
	}
}
