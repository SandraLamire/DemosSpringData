package fr.eni.gestionavis.requetes;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import fr.eni.gestionavis.bo.Avis;
import fr.eni.gestionavis.dal.AvisRepository;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
@TestMethodOrder(MethodOrderer.MethodName.class)
class TestRequetes {
	@Autowired
	AvisRepository avisRepository;

	@Test
	void test01_findByNoteLessThan_3() {
		List<Avis> listeAvis = avisRepository.findByNoteLessThan(3);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isGreaterThan(1);
		log.info("Le nombre d'Avis avec une note < 3 est de : " + listeAvis.size());
		log.info(listeAvis.toString());
	}

	@Test
	void test02_findByNoteBouteilleGreaterThan_2() {
		// GreaterThan à 2 pour que ce soit bien note >= 3
		List<Avis> listeAvis = avisRepository.findByNoteGreaterThan(2);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isGreaterThan(1);
		log.info("Le nombre d'Avis avec une note >= 3 est de : " + listeAvis.size());
		log.info(listeAvis.toString());
	}

	@Test
	void test03_findByBouteille() {
		Integer idBouteille = 18298;
		
		List<Avis> listeAvis = avisRepository.findByBouteilleIdBouteille(idBouteille);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isEqualTo(3);
		log.info(listeAvis.toString());
	}

	@Test
	void test04_findByClientPseudo_bobeponge() {
		String pseudo = "bobeponge@email.fr";

		List<Avis> listeAvis = avisRepository.findByClientPseudo(pseudo);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isEqualTo(3);
		log.info(listeAvis.toString());
	}

	@Test
	void test05_findByClientQuantiteCommandeeGreaterThan_100() {
		int qte = 100;

		List<Avis> listeAvis = avisRepository.findByClientQuantiteCommandeeGreaterThan(qte);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isEqualTo(4);// 108 - 324 - 400 - 1600
		log.info(listeAvis.toString());
	}

	@Test
	void test06_findByDateBetween() {
		LocalDateTime debut = LocalDateTime.of(2023, 7, 13, 12, 28);
		LocalDateTime fin = LocalDateTime.of(2023, 7, 31, 15, 28);

		List<Avis> listeAvis = avisRepository.findByDateBetween(debut, fin);
		assertThat(listeAvis).isNotNull();
		assertThat(listeAvis).isNotEmpty();
		assertThat(listeAvis.size()).isEqualTo(6);
		log.info(listeAvis.toString());
	}
}
