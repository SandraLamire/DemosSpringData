package fr.eni.gestionavis.aop;

import java.util.List;

import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import fr.eni.gestionavis.bo.Avis;
import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class LogAspect {

	@Before("execution(public * *..AvisRepository.findByNote*(int))")
	public void before(JoinPoint jp) {
		log.warn("ENI AOP - @Before - " + jp.getSignature().getName());
	}

	@Around(value = "execution(public * *..AvisRepository.findByNote*(..))")
	public Object around(ProceedingJoinPoint call) throws Throwable {
		Object result = null;
		long before = System.currentTimeMillis();

		result = call.proceed();
		long after = System.currentTimeMillis();
		long duration = after - before;
		String nomMethode = call.getSignature().getDeclaringTypeName() + "/"
				+ call.getSignature().getName();
		log.warn("ENI AOP - @Around - " + nomMethode + ":" + duration + " ms");
		return result;
	}
		
	@AfterReturning(pointcut = "execution(public * *..AvisRepository.findByClient*(..))", returning = "result")
	public void afterReturning(JoinPoint jp, List<Avis> result) {
		log.warn("ENI AOP - @AfterReturning - TRY - RETURN [" + jp.getSignature().getName() + "] = " + result);
	}
}
