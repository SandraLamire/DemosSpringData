package fr.eni.gestionavis.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import lombok.AllArgsConstructor;

@ControllerAdvice
@AllArgsConstructor
public class AppExceptionHandler {

	// Préciser les exceptions à gérer
	@ExceptionHandler(value = { Exception.class })
	public ResponseEntity<String> capturerException(Exception ex) {
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_ACCEPTABLE);
	}
}
